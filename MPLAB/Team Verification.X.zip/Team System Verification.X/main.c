 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
© [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include <ctype.h>

uint16_t ms=0;
uint16_t sec=0;

#define CTRL1 0x03
#define CTRL2 0x04
#define CTRL3 0x05

void DRV8889_WriteRegister(uint8_t address, uint8_t data) {
    uint16_t command = ((address & 0x1F) << 10) | (data << 1); // Format per datasheet

    CS_SetLow();
    SPI2_ByteWrite((command >> 8) & 0xFF);  // Send MSB first
    SPI2_ByteWrite(command & 0xFF);         // Send LSB
    CS_SetHigh();
    __delay_us(1);  // Ensure 500 ns between frames
}


void timer_callback(void)
{
    ms++;
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
    //    IO_RA2_Toggle();
    }
}

void eusart_callback(void)
{
//    ms++;
}

uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}
        

#define BUFSIZE 4
#define MSGSIZE 64
#define TEAMSIZE 4
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

const char broadcast_id='X';
const char my_id='h';
const char team_ids[TEAMSIZE+1] = "fhlm";
char buffer_in[BUFSIZE+1];
char message_in[MSGSIZE+1];
char message_out[MSGSIZE+1];
//char mode = '0', LB = '0', RB = '0'; 
int mode = 0, LB = 0, RB = 0; 
int S1 = 0, S2 = 0, S3 = 0, S4 = 0;
int V = 0;
int flag = 1;
//char stream_in[]="-----AZcb34567890YB-----------AZcd34567890YB--AZed34567890YB--AZdz34567890YB---AZed1234567890123456789012345678901234567890123456789012345678YB-";
//char read_char(void){
//    static int ii=0;
//    char c = stream_in[ii];
//    ii++;
//    if (ii>=(sizeof stream_in)-1)
//    {ii=0;}
//    return c;
//}

void fill_string(char * mystring,char value,unsigned int size){
    for (int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
//        printf("%c,%c;",value,mystring[ii]);
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii){
    message_in[ii-2]=0;
    
   // printf("AZbaPIC: handling: %sYB",message_in+4);
}

void step_motor(bool direction)
{
    if (direction)
        DIR_SetHigh();   // Right
    else
        DIR_SetLow();    // Left

for (uint16_t i = 0; i < 200; i++)  // Adjust 200 for speed/steps
    {
        STEP_SetHigh();
        __delay_ms(1);
        STEP_SetLow();
        __delay_ms(9);  // 10ms total between steps
    }
}

int main(void)
{

    char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;
    bool isValidData;
    
    SPI2_Initialize();
    SPI2_Open(HOST_CONFIG);
    
    
    CS_SetLow();
    DRV8889_WriteRegister(CTRL1, 0x40);
    CS_SetHigh();
    
    CS_SetLow();
    DRV8889_WriteRegister(CTRL2, 0x8F);
    CS_SetHigh();
    
    uint16_t ms_last=0;
    uint16_t sec_last=0;
    SYSTEM_Initialize();
    nSLEEP_SetHigh();
    DRVOFF_SetLow();
    
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    TMR1_Initialize();
    TMR1_Start();
    TMR1_TMRInterruptEnable();

    TMR1_OverflowCallbackRegister(timer_callback);

    EUSART1_Initialize();
    EUSART1_Enable();
//    EUSART1_TransmitEnable();
//    EUSART1_ReceiveEnable();
//    EUSART1_TransmitInterruptEnable();
//    EUSART1_ReceiveInterruptEnable();
//    
//    UART1_RxCompleteCallbackRegister(eusart_callback);

//sprintf(message_out,"AZNKK2YB");
//    printf("%lu", sizeof buffer_in);
while (1)
{
    if (EUSART1_IsRxReady())
    {
        c = EUSART1_Read();
        buffer_in[buffer_ii] = c;

        // Message Start Detected
        if (buffer_in[buffer_last_ii] == 'A' && c == 'Z')
        {
            message_incoming = 1;
            message_ii = 0;
            fill_string(message_in, '_', MSGSIZE);
            message_in[0] = 'A';
            message_ii = 1;
        }
        // reset validity flag at the start of message processing
        isValidData = true;
        // Store Incoming Message
        if (message_incoming)
        {
            message_in[message_ii++] = c;
            // SECURITY CHECK
            if (message_ii == 4)
            {
                if(!(find_char(team_ids,buffer_in[buffer_last_ii],TEAMSIZE)))
                {
                    printf("AZmhPIC:SenderNotinTeamYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                if (message_in[3] == broadcast_id)
                {
                   // printf("AZmhPIC:BroadcastingYB");
                    flag = 0;
                }
                else if (!(find_char(team_ids,c,TEAMSIZE)))
                {
                    printf("AZmhPIC:RecieverNotinTeamYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                if ((message_in[2] == my_id) && flag == 1)
                {
                    printf("AZmhPIC:DuplicateMessageDeletedYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                              
            }
            // Check for message end
            if (c == 'B' && buffer_in[buffer_last_ii] == 'Y')
            {
                message_incoming = 0;
                message_in[message_ii] = '\0'; // Null-terminate the message
               // handle_message(message_ii);
                
                
                // Reset values before processing the new message
                V = 0;
                S1 = 0;
                S2 = 0;
                S3 = 0;
                S4 = 0;

// Now process the values after the message is fully received
// Process V
if (find_char(message_in, 'V', message_ii)) // Check if 'V' is in the message
{
    for (unsigned int i = 0; i < message_ii; i++)
    {
        if (message_in[i] == 'V')
        {
            // Check if there are exactly 4 characters after 'V'
            if (i + 4 < message_ii) // Ensure there are enough characters
            {
                // Check if the next four characters are digits
                if (isdigit(message_in[i + 1]) && isdigit(message_in[i + 2]) &&
                    isdigit(message_in[i + 3]) && isdigit(message_in[i + 4]))
                {
                    // Check if there are no more characters after the four digits
                    if (i + 5 < message_ii && isdigit(message_in[i + 5]))
                    {
                        printf("AZhlPIC: BadData - V must be followed by exactly 4 digits YB");
                        isValidData = false; // Mark as invalid 
                        V = 0; // Reset V
                    }
                    else
                    {
                        V = (message_in[i + 1] - '0') * 1000 +
                            (message_in[i + 2] - '0') * 100 +
                            (message_in[i + 3] - '0') * 10 +
                            (message_in[i + 4] - '0'); // Read the next four characters
                    }
                }
                else
                {
                    printf("AZhlPIC: BadData - V must be followed by 4 digits YB");
                    isValidData = false; // Mark as invalid
                    V = 0; // Reset V
                }
            }
            else
            {
                printf("AZhlPIC: BadData - V must be followed by 4 digits YB");
                isValidData = false; // Mark as invalid
                V = 0; // Reset V
            }
            break; // Exit the loop after processing 'V'
        }
    }
}

// Process S1, S2, S3, and S4
for (unsigned int i = 0; i < message_ii; i++)
{
    if (message_in[i] == 'S')
    {
        // Check if the next character is a digit (1-4)
        if (i + 1 < message_ii && message_in[i + 1] >= '1' && message_in[i + 1] <= '4')
        {
            int sensorIndex = message_in[i + 1] - '1'; // Get index (0 for S1, 1 for S2, etc.)
            if (i + 2 < message_ii) // Ensure there is a character for the value
            {
                // Check if there are exactly 4 characters after 'S1', 'S2', 'S3', or 'S4'
                if (i + 5 < message_ii) // Ensure there are enough characters
                {
                    // Check if the next four characters are digits
                    if (isdigit(message_in[i + 2]) && isdigit(message_in[i + 3]) &&
                        isdigit(message_in[i + 4]) && isdigit(message_in[i + 5]))
                    {
                        // Check if there are no more characters after the four digits
                        if (i + 6 < message_ii && isdigit(message_in[i + 6]))
                        {
                            printf("AZhlPIC: BadData - S%d must be followed by exactly 4 digits YB", sensorIndex + 1);
                            isValidData = false; // Mark as invalid
                            switch (sensorIndex)
                            {
                                case 0: S1 = 0; break; // Reset S1
                                case 1: S2 = 0; break; // Reset S2
                                case 2: S3 = 0; break; // Reset S3
                                case 3: S4 = 0; break; // Reset S4
                            }
                        }
                        else
                        {
                            int sensorValue = (message_in[i + 2] - '0') * 1000 +
                                              (message_in[i + 3] - '0') * 100 +
                                              (message_in[i + 4] - '0') * 10 +
                                              (message_in[i + 5] - '0'); // Read the next four characters
                            // Assign the value to the corresponding variable
                            switch (sensorIndex)
                            {
                                case 0: S1 = sensorValue; break; // S1
                                case 1: S2 = sensorValue; break; // S2
                                case 2: S3 = sensorValue; break; // S3
                                case 3: S4 = sensorValue; break; // S4
                            }
                        }
                    }
                    else
                    {
                        printf("AZhlPIC: BadData - S%d must be followed by 4 digits YB", sensorIndex + 1);
                        isValidData = false; // Mark as invalid
                        switch (sensorIndex)
                        {
                            case 0: S1 = 0; break; // Reset S1
                            case 1: S2 = 0; break; // Reset S2
                            case 2: S3 = 0; break; // Reset S3
                            case 3: S4 = 0; break; // Reset S4
                        }
                    }
                }
                else
                {
                    printf("AZhlPIC: BadData - S%d must be followed by 4 digits YB", sensorIndex + 1);
                    isValidData = false; // Mark as invalid
                    switch (sensorIndex)
                    {
                        case 0: S1 = 0; break; // Reset S1
                        case 1: S2 = 0; break; // Reset S2
                        case 2: S3 = 0; break; // Reset S3
                        case 3: S4 = 0; break; // Reset S4
                    }
                }
            }
        }
    }
}

                if(isValidData)
                {
                    // Format the response message
                    
                    // Motor control based on S1 and S2 comparison
                    // Motor control logic
                    if (mode == 0)  // Automatic
                    {
                        if (S1 > S2)
                            step_motor(false); // Turn left
                           //DRV8889_WriteRegister(CTRL3, 0xF0);
                        else if (S2 > S1)
                            step_motor(true);  // Turn right
                            //DRV8889_WriteRegister(CTRL3, 0x70);
                    }
                    else if (mode == 1)  // Manual
                    {
                        if (LB == 1 && RB == 0)
                            step_motor(false); // Turn left
                            //DRV8889_WriteRegister(CTRL3, 0xF0);
                        else if (RB == 1 && LB == 0)
                            step_motor(true);  // Turn right
                            //DRV8889_WriteRegister(CTRL3, 0x70);
                        // If both or neither are pressed, do nothing
                    }
                    // DEBUGGING 
                    fill_string(message_out,'\0',MSGSIZE);
                    if (flag)
                    {
                        // sprintf(message_out, "AZhlM%dS1%04dS2%04dS3%04dS4%04dV%04dL%dR%dYB", mode, S1, S2, S3, S4, V, LB, RB);
                        sprintf(message_out, "AZhlS1%04dS2%04dYB", S1, S2);
                    }
                    else
                    {
                        for (int i = 0; i < message_ii; i++)
                        {
                            message_out[i] = message_in[i];
                        }
                    }
                    if (!flag)
                    {
                        flag = 1;
                    }
                    // SENDING/TRANSMITTING
                    // sprintf(message_out, "AZHLV%04dYB",V);

                    // Send the response
                    for (int i = 0; message_out[i] != '\0'; i++)
                    {
                        while (!EUSART1_IsTxReady()); // Wait until ready
                        EUSART1_Write(message_out[i]);
                    }
                }
            }
                
            

            // Prevent Buffer Overflow
            if (message_ii >= MSGSIZE)
            {
                printf("AZbaPIC:messagetoolargeYB");
                message_incoming = 0;
            }
        }

        // Update mode, LB, and RB when detected
        if (buffer_in[buffer_last_ii] == 'M')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                mode = buffer_in[buffer_ii] - '0';
                // Print messages based on the value of mode
            }
            else
            {
                printf("AZhlPIC:BadDataForModeYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        if (buffer_in[buffer_last_ii] == 'L')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                LB = buffer_in[buffer_ii] - '0';
            }
            else
            {
                printf("AZhlPIC:BadDataForLeftButtonYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        if (buffer_in[buffer_last_ii] == 'R')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                RB = buffer_in[buffer_ii] - '0';
            }
            else
            {
                printf("AZhlPIC:BadDataForRightButtonYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }



        // Update indices
        buffer_last_ii = buffer_ii;
        buffer_ii = (buffer_ii + 1) % BUFSIZE;
    }
}
                
                
    //        printf("%s,%s",buffer_in,message_in);
           
         
//        if ((sec%3==0) & (sec!=sec_last)){
//            sprintf(message_out,"AZbaPIC: Heartbeat %u YB",sec);
//            send_message(message_out);
////            printf("AZbaPIC: Heartbeat %u YB",sec);
//        }
        
//        if (IO_RC2_GetValue()!=0)
//        {return 1;}
        
        sec_last = sec;
        ms_last = ms;
        __delay_ms(3000);
    }